const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');

const config = {
  entry: {
    main: './src/index.js',
  },
  output: {
    filename: '[name].bundle.js',
    path: path.resolve(__dirname, 'dist'),
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      hash: true,
      title: 'Sample Extension',
      template: './src/index.html',
      filename: './index.html',
      chunks: ['main'],
      scriptLoading: 'blocking',
    }),
  ],
  devServer: {
    static: {
      directory: path.join(__dirname, 'dist'),
    },
    https: true,
    compress: true,
    port: 7070,
  },
};

module.exports = (env, argv) => {
  const { mode } = argv;
  config.mode = mode;

  if (argv.mode === 'development') {
    config.devtool = 'source-map';
    config.watch = true;
  }

  return config;
};
