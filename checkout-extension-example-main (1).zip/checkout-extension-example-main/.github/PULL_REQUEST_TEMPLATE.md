## What?
...

## Why?
...

## Testing / Proof
...

@bigcommerce/team-checkout
