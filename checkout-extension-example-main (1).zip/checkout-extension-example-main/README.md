# checkout-extension-sample
An example of BC checkout extension.

## Requirements

In order to build from the source code, you must have the following set up in your development environment.

* Node v20.
* NPM v9.
* Unix-based operating system.

One of the simplest ways to install Node is using [NVM](https://github.com/nvm-sh/nvm#installation-and-update). You can follow their instructions to set up your environment if it is not already set up.

## Development
Once you have cloned the repository and set up your environment, you can start developing with it.

First, you have to pull in the dependencies required for the application.

```sh
npm ci
```

If you are developing the application locally and want to build the source code in watch mode, you can run the following command:

```sh
npm run serve
```

## Release & Deployment
For creating a production folder run the following command
```sh
npm run build
```

This will create a `dist` folder with a bundled JS file and index.html.

Deploy the folder on CDN of your choice.
