import {
  loadingIndicator,
  reloadCheckout,
  setIframeStyle,
} from './commands';
import {
  compareConsignments,
} from './helper-methods';
import './style.css';

const script = document.createElement('script');
script.onload = function () {
  checkoutKitLoader.load('extension').then(async function (module) {
    const params = new URL(document.location).searchParams;
    const extensionId = params.get('extensionId');
    const parentOrigin = params.get('parentOrigin');
    const extensionService = await module.initializeExtensionService({
      extensionId,
      parentOrigin,
      taggedElementId: 'content',
    });

    console.log('extension service instantiated');

    // reload checkout
    const reloadButton = document.getElementById('reload-checkout');
    reloadButton.addEventListener(
      'click',
      reloadCheckout.bind(this, extensionService)
    );

    // show modal
    const showModal = document.getElementById('show-modal');
    showModal.addEventListener(
      'click',
      setIframeStyle.bind(this, extensionService)
    );

    // show loading indicator
    const loadingIndicatorButton = document.getElementById('show-indicator');
    loadingIndicatorButton.addEventListener(
      'click',
      loadingIndicator.bind(this, extensionService)
    );

    // subscribe to consignment changes
    extensionService.addListener('EXTENSION:CONSIGNMENTS_CHANGED', (data) => {
      compareConsignments(data.payload.consignments, data.payload.previousConsignments);
    });

  });
};

script.src = 'https://checkout-sdk.bigcommerce.com/v1/loader.js';
document.head.appendChild(script);
