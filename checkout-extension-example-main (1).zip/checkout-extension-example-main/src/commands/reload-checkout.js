import {ExtensionCommandType} from "@bigcommerce/checkout-sdk";

export function reloadCheckout(extensionService) {
  extensionService.post({ type: ExtensionCommandType.ReloadCheckout });
}
