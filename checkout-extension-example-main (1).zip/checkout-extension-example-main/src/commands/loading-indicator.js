import {ExtensionCommandType} from "@bigcommerce/checkout-sdk";

export function loadingIndicator(extensionService) {
  extensionService.post({
    type: ExtensionCommandType.ShowLoadingIndicator,
    payload: { show: true },
  });

  setTimeout(() => {
    extensionService.post({
      type: ExtensionCommandType.ShowLoadingIndicator,
      payload: { show: false },
    });
  }, 1000);
}
