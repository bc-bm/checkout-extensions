import {ExtensionCommandType} from "@bigcommerce/checkout-sdk";

export function setIframeStyle(extensionService) {
  document.getElementsByClassName('extension-actions')[0].style.display =
    'none';
  document.getElementsByClassName('modal-content')[0].style.display = 'block';
  document.getElementById('log').style.display = 'none';

  extensionService.post({
    type: ExtensionCommandType.SetIframeStyle,
    payload: {
      style: {
        background: 'rgba(0,0,0,.6)',
        left: '0',
        position: 'fixed',
        top: '0',
        zIndex: 10000,
      },
    },
  });

  // This is to let iframe resizer know to set the height of iframe to 100vh
  setTimeout(() => {
    extensionService.post({
      type: ExtensionCommandType.SetIframeStyle,
      payload: {
        style: {
          height: '100vh',
        },
      },
    });
  }, 40);

  setTimeout(() => {
    document.getElementsByClassName('extension-actions')[0].style.display =
        'block';
    document.getElementsByClassName('modal-content')[0].style.display = 'none';
    document.getElementById('log').style.display = 'block';

    extensionService.post({
      type: ExtensionCommandType.SetIframeStyle,
      payload: {
        style: {
          background: 'white',
          position: 'static',
        },
      },
    });
  }, 3000);
}
