export function compareConsignments(consignments, previousConsignments) {
  consignments.forEach((consignment) => {
    const { id, shippingAddress: { country } } = consignment;

    if (previousConsignments.length === 0) {
      log(`️🔄 Consignment #${id} now shipping to: ${country}.`);
    } else {
      const prevConsignment = previousConsignments.find(prev => prev.id === id);
      const previousCountry = prevConsignment.shippingAddress.country;

      if (country !== previousCountry) {
        log(`️🔄 Consignment #${id} shipping country change: ${previousCountry} -> ${country}.`);
      }
    }
  });
}

export function log(content){
  const item = document.createElement('p');

  item.innerHTML = content;

  document.getElementById('log').prepend(item);
}
